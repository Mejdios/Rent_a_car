<?php
include('header.php');
?>
    <!--code  ici pour les  pages -->






<section class="content-header">
      <h1>
      
        <small>Panneau de contrôle</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Accueil</a></li>
        <li class="active"></li>
      </ol>
    </section>







	<script src="ckeditor/ckeditor.js"></script>
	<script src="ckeditor/page/js/sample.js"></script>
	
	<link rel="stylesheet" href="toolbarconfigurator/lib/codemirror/neo.css">
</head>


<br>

<form action="pages/pageseditor.php" method="post" height="900px">

	<div class="adjoined-bottom">
		<div class="grid-container">
			<div class="grid-width-100">
			
					


<?php

if(isset($_GET['id']))
{
	if(!empty($_GET['id']))
	{
$page=$_GET['id'];
$sql = " SELECT  * FROM pages where id_page=$page  ";

$reponse = $bdd->query($sql);

// On affiche chaque entrée une à une
while ($donnees = $reponse->fetch())
{

?>
<input type="hidden" name="c" value="<?php echo $donnees['id_page'];?>"/>
<textarea  id="editor" name="editor" height="980px;">

	<?php echo $donnees['contenu']; ?>



</textarea>


<?php
}}}
?>
				
			</div>
		</div>
	</div>

	</form>

		















<script>
	initSample();
</script>

































<?php

include('footer.php');

?>











<!--code  ici pour les  pages -->

 