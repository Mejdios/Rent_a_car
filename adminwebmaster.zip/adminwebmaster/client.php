<?php
include('header.php');
?>

    <!--code  ici pour les  pages -->






    <section class="content-header">
      <h1>
         Clients
        <small>Panneau de contrôle</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Accueil</a></li>
        <li class="active">Liste des Clients</li>
      </ol>
    </section>
<br>




       <div class="box">
            <div class="box-header">
              <h3 class="box-title">Liste des Clients </h3>
            </div>
          
            <div class="table-responsive">
<table  id="example1" class="table table-bordered table-striped" >
        <thead style="background:red; color:#ffffff;">
            <tr>
                <th>Nom</th>
                <th>Prenom</th>
                <th>Numero de  telephone</th>
                <th>Adresse email</th>
               <th>Action</th>

            </tr>
        </thead>
      
        <tbody>

<?php








$sql = " SELECT  * FROM client limit 0,20 ";

$reponse = $bdd->query($sql);

// On affiche chaque entrée une à une
while ($donnees = $reponse->fetch())
{

?>

            <tr> 
             
                <td><?php echo $donnees['nom'];?></td>
                <td><?php echo $donnees['prenom'];?></td>
                <td><?php echo $donnees['numero_telephone'];?></td>
                
                <td><?php echo $donnees['adressemail'];?></td>
                

                <input type="hidden"   name="sup" value="<?php echo $donnees['id_client'];?>"/>
<td>
    <a class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal<?php echo $donnees['id_client']; ?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
      <a class="btn btn-danger btn-sm"  href="pages/supprimerclient.php?id=<?php echo $donnees['id_client'];?>"  ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
</td>
</tr> 
<!-- Modal -->
<div class="modal fade" id="myModal<?php echo $donnees['id_client']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel<?php echo $donnees['id_client']; ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"   id="myModalLabel<?php echo $donnees['id_client']; ?>">Modifier Client </h4>
      </div>
      <div class="modal-body">

<form  action="pages/modifierclient.php" method="POST">

<input type="hidden"   name="x" value="<?php echo $donnees['id_client'];?>"/>
  <div class="form-group">
    <label for="nm">Nom</label>
    <input type="text" class="form-control" name="nom" value="<?php echo $donnees['nom']; ?>">
  </div>
  <div class="form-group">
    <label for="gd">Prenom</label>
    <input type="text" class="form-control"   name="prenom"  value="<?php echo $donnees['prenom']; ?>">
  </div>
 <div class="form-group">
    <label for="gd">Telephone</label>
    <input type="text" class="form-control"   name="tel"  value="<?php echo $donnees['numero_telephone']; ?>">
  </div>
   <div class="form-group">
    <label for="gd">Adresse E-mail</label>
    <input type="text" class="form-control"   name="eml"  value="<?php echo $donnees['adressemail']; ?>">
  </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
        <button type="submit"  class="btn btn-primary">Sauvgarder</button></form>
      </div>
      </div>
      
    </div>
  </div>
</div>

</td>
</tr>
<?php
}
?>
  </tbody>
      </table>





















<!--code  ici pour les  pages -->

      
<?php

include('footer.php');

?>