

/*
$('.treeview li a').click(function(){
var q = $(this).attr("href");
	$("#contenu").load(q);
	return false;
});

$('#clicks').click(function(){
var q = $(this).attr("href");
	$("#contenu").load(q);
	return false;
});
$('#clickss').click(function(){
var q = $(this).attr("href");
	$("#contenu").load(q);
	return false;
});

$('#clients').click(function(){
var q = $(this).attr("href");
	$("#contenu").load(q);
	return false;
});

$('#recherche').click(function(){
var q = $(this).attr("href");
	$("#contenu").load(q);
	return false;
});
