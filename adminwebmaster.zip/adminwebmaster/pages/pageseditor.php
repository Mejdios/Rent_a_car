<?php
include_once '../idents.php';
if(isset($_POST['editor']))
{

$contenu=$_POST['editor'];
$id=$_POST['c'];

$b=$bdd->prepare("UPDATE pages SET contenu= :contenu   where id_page=$id ");
$b->bindParam(":contenu",$contenu);
$b->execute();

header('location:../pages.php?id=1');
}


?>