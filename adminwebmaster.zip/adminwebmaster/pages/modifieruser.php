<?php


include_once '../idents.php';

$xx=$_POST['xx'];
$login=$_POST['login'];
$pass=sha1($_POST['pass']);
$email=$_POST['emailuser'];
$action=$_POST['action'];

$b=$bdd->prepare("UPDATE users SET login= :login , pass= :pass , mail= :email , valid= :action   where id=$xx ");
$b->bindParam(":login",$login);
$b->bindParam(":pass",$pass);
$b->bindParam(":email",$email);
$b->bindParam(":action",$action);



$b->execute();


if($b->execute())
{


header('location:../users.php');

}

else
{
	header('location:../users.php');
}




?>
