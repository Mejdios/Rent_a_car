<?php
$conn = new mysqli("localhost", 
	               "dietnsgk_mejdi", 
	               "hmimide", 
	               "dietnsgk_rentcar");
if ($conn->connect_errno) {
    echo "Failed to connect to MySQL: (" . $conn->connect_errno . ") " . $conn->connect_error;
}
?>
