

<?php

include('header.php');

?>


<table class="table table-hover">
        <thead>
            <tr>
                <th>nom</th>
                <th>prenom</th>
                <th>numero de  telephone</th>
                <th>adresse email</th>
              

            </tr>
        </thead>

<?php
include_once('idents.php');

if(isset($_POST['recherche']))

{
    if(!empty($_POST['recherche']))
{
$r=$_POST['recherche'];

$sql = " SELECT  *  FROM client where nom like '$r' || prenom like '$r' || numero_telephone like '$r' || adressemail like '$r' ";

$reponse = $bdd->query($sql);

// On affiche chaque entrée une à une
while ($donnees = $reponse->fetch())
{

?>

<tr> 
             
                <td><?php echo $donnees['nom'];?></td>
                <td><?php echo $donnees['prenom'];?></td>
                <td><?php echo $donnees['numero_telephone'];?></td>
                
                <td><?php echo $donnees['adressemail'];?></td>
              </tr>


<?php

}
}

}

?>    

</table>



<?php

include('footer.php');

?>













