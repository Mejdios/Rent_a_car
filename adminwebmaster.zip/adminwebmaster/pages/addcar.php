<?php
include_once '../idents.php';
if(isset($_POST['b'],$_POST['c'],$_POST['d'],$_FILES['avatar'])){
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];
$e = $_POST['e'];
$f = $_POST['f'];
$g = $_POST['g'];
$h = $_POST['h'];
$i= $_POST['i'];
$j = $_POST['j'];
$fileToUpload = $_FILES['avatar']['name'];
if($b != null && $c != null && $d != null && $e != null&& $f != null&& $g != null&& $h != null&& $i != null&& $j != null&& $fileToUpload != null ){
 $insert_q = $bdd->prepare("INSERT INTO vehicule(nom, marque, typecarburant, prixjours, matricule, port, passager, Type, clim, image) VALUES (:b, :c, :d ,:e ,:f , :g ,:h , :i ,:j,:fileToUpload )"); # Insertion dans la table d'une nouvelle news
	 $insert_q->execute(array(
		'b' => $b,
		'c' => $c,
		'd' => $d,
		'e' => $e,
		'f' => $f,
		'g' => $g,
		'h' => $h,
		'i' => $i,
		'j' => $j,
		'fileToUpload'=>$fileToUpload,));





     $dossier = 'uploads/';
     $fichier = basename($_FILES['avatar']['name']);
     
     if(move_uploaded_file($_FILES['avatar']['tmp_name'], $dossier . $fichier)) 
     {
          header('location:../vehicule.php');
          echo 'Upload effectué avec succès !';
     }
     else //Sinon (la fonction renvoie FALSE).
     {
          echo 'Echec de l\'upload !';
     }




     

















}

}

?>
