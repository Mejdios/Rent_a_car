<?php
include_once '../idents.php';

$x=$_POST['x'];
$ma=$_POST['marque'];
$ca=$_POST['carburant'];
$p=$_POST['port'];
$pa=$_POST['passager'];
$px=$_POST['prix'];
$n=$_POST['nom'];
$t=$_POST['Type'];
$c=$_POST['clim'];
$d=$_POST['disponible'];

/*
$insert_q = $bdd->prepare("update  vehicule set  marque= :m, typecarburant= :ca, prixjours= :px, disponible= :d, port= :p, passager= :pa, Transmission= :t, clim= :c  where id_V= :c "); # Insertion dans la table d'une nouvelle news
	 $insert_q->execute(array(
		'n' => $n,
		'm' => $m,
		'ca' => $ca,
		'px' => $px,
		'd' => $d,
		'p' => $p,
		'pa' => $pa,
		't' => $t,
		'c' => $c,
	
		
		
		));
*/






$b=$bdd->prepare("UPDATE vehicule SET marque=:ma ,typecarburant=:ca ,nom = :n , prixjours= :px, matricule= :d, port= :p, passager= :pa, Type= :t, clim= :c    where id_v=$x");
$b->bindParam(":ma",$ma);
$b->bindParam(":ca",$ca);
$b->bindParam(":px",$px);
$b->bindParam(":d",$d);
$b->bindParam(":p",$p);
$b->bindParam(":pa",$pa);
$b->bindParam(":t",$t);
$b->bindParam(":c",$c);
$b->bindParam(":n",$n);


$b->execute();


header('location:../vehicule.php');






?>