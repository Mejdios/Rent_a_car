<?php
include_once 'config.php';

if(isset($_GET['id'])){
	
	$id = $_GET['id'];
	$stmt = $conn->prepare("delete from reservation where Reference=? ");
    $stmt->bind_param('s', $id);
}
if($stmt->execute()){



header('location:../reservation_liste.php');
} 


?>

