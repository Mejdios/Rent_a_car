<?php

include_once '../idents.php';
if(isset($_GET['id'])){


$s=$_GET['id'];


$sql =$bdd->query(" SELECT  * FROM sliderimage where id=$s  ");
$fetch=$sql->fetch(PDO::FETCH_ASSOC);
if(file_exists('ve/'.$fetch["nom"]))
{

	unlink('ve/'.$fetch["nom"]);
}



header('location:../slider.php');

$sql =$bdd->query(" DELETE FROM sliderimage where id=$s  ");






}


 ?> 
