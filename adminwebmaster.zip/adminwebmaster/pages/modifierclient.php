<?php


include_once '../idents.php';

$x=$_POST['x'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$tel=$_POST['tel'];
$eml=$_POST['eml'];




echo $x;



$b=$bdd->prepare("UPDATE client SET nom=:nom ,prenom=:prenom ,numero_telephone = :tel , adressemail= :eml where id_client=$x");
$b->bindParam(":nom",$nom);
$b->bindParam(":prenom",$prenom);
$b->bindParam(":tel",$tel);
$b->bindParam(":eml",$eml);

$b->execute();


header('location:../client.php');





?>