<?php
include_once'../idents.php';

$xx=$_POST['mod'];
$cn=$_POST['r3'];
$b=$bdd->prepare("UPDATE reservation SET confirmation_reservation= :cn   where Reference=$xx ");
$b->bindParam(":cn",$cn);

$b->execute();


if($b->execute())
{
header('location:../reservation_liste.php');
}



?>