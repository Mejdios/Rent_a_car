<?php
include_once 'config.php';

if(isset($_GET['id'])){
	
	$id = $_GET['id'];
	$stmt = $conn->prepare("delete from vehicule where id_v=? ");
    $stmt->bind_param('s', $id);
}
if($stmt->execute()){



header('location:../vehicule.php');
} 


?>

