<?php



include_once '../idents.php';




if(isset($_POST['nomuser'], $_POST['emailuser'], $_POST['motdepasse'], $_POST['actions'])) # Si le formulaire est soumis
{
 if (!empty($_POST['nomuser']) && !empty($_POST['emailuser']) && !empty($_POST['motdepasse']) )
 {

 $login = $_POST['nomuser'];

 $emailuser=$_POST['emailuser'];

 $motdepasse = sha1($_POST['motdepasse']);

  $action=$_POST['actions'];



 $insert_q = $bdd->prepare("INSERT INTO users(login, pass, mail, valid) VALUES (:login, :motdepasse  , :emailuser,  :action)"); # Insertion dans la table d'une nouvelle news
   $insert_q->execute(array(
    'login' => $login,
     'motdepasse'=>$motdepasse,
    'emailuser' => $emailuser,
   
    'action'=>$action,
    
    
   ));

 }
}


header('location:../users.php');
?>