<?php
include "idents.php";
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];

if($b != null && $c != null && $d != null ){
 $insert_q = $bdd->prepare("INSERT INTO vehicule(nom, marque, typecarburant) VALUES (:b, :c, :d )"); # Insertion dans la table d'une nouvelle news
	 $insert_q->execute(array(
		'b' => $b,
		'c' => $c,
		'd' => $d,
		));
}
if($insert_q())
{
	echo "cbon";
}
?>