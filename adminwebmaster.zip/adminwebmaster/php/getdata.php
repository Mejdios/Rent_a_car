


    <div class="row">
        <div class="col-xs-11">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Véhicules</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">        






<table  class="table table-bordered table-hover">
  <thead>
    <tr>
               <th>Profile</th>
                <th>marque</th>
                <th>carburant</th>
                <th>prix</th>
                <th>port</th>
                <th>passager</th>
                <th>nom</th>
                <th>Transmission</th>
                <th>clim</th>
                <th>Disponible</th>
    </tr>
  </thead>
  <tbody>
<?php
include "config.php";
$res = $conn->query("SELECT  id_v, image, marque, typecarburant, prixjours, port, passager, nom ,Transmission,clim , disponible FROM vehicule");
while ($row = $res->fetch_assoc()) {
?>
    
    <tr>
                <td><img src="../assets/<?php echo $row['image'];?>"width="80px" class="user-image"/></td>
                <td><?php echo $row['marque'];?></td>
                <td><?php echo $row['typecarburant'];?></td>
                <td><?php echo $row['prixjours'];?></td>
                
                <td><?php echo $row['port'];?></td>
                <td><?php echo $row['passager'];?></td>
                <td><?php echo $row['nom'];?></td>
                <td><?php echo $row['Transmission'];?></td>
                <td><?php echo $row['clim'];?></td>
                <td><?php echo $row['disponible'];?></td>
                <td>
      <a class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal<?php echo $row['id_v']; ?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
      <a class="btn btn-danger btn-sm"  onclick="deletedata('<?php echo $row['id_v']; ?>')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
</td>
<!-- Modal -->
<div class="modal fade" id="myModal<?php echo $row['id_v']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel<?php echo $row['id_v']; ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel<?php echo $row['id_v']; ?>">Modifier</h4>
      </div>
      <div class="modal-body">

<form>
  <div class="form-group">
    <label for="b">Marque</label>
    <input type="text" class="form-control" id="b<?php echo $row['id_v']; ?>" value="<?php echo $row['marque']; ?>">
  </div>
  <div class="form-group">
    <label for="c">Type de carburant</label>
    <input type="text" class="form-control" id="c<?php echo $row['id_v']; ?>" value="<?php echo $row['typecarburant']; ?>">
  </div>
  <div class="form-group">
    <label for="d">Prixjours</label>
    <input type="text" class="form-control" id="d<?php echo $row['id_v']; ?>" value="<?php echo $row['prixjours']; ?>">
  </div>
  <div class="form-group">
    <label for="e">Port</label>
    <input type="text" class="form-control" id="e<?php echo $row['id_v']; ?>" value="<?php echo $row['port']; ?>">
  </div>
  <div class="form-group">
    <label for="f">Passager</label>
    <input type="text" class="form-control" id="f<?php echo $row['id_v']; ?>" value="<?php echo $row['passager']; ?>">
  </div>
  <div class="form-group">
    <label for="g">Nom</label>
    <input type="text" class="form-control" id="g<?php echo $row['id_v']; ?>" value="<?php echo $row['nom']; ?>">
  </div>
  <div class="form-group">
    <label for="h">Transmission</label>
    <input type="text" class="form-control" id="h<?php echo $row['id_v']; ?>" value="<?php echo $row['Transmission']; ?>">
  </div>
  <div class="form-group">
    <label for="i">Clim</label>
    <input type="text" class="form-control" id="i<?php echo $row['id_v']; ?>" value="<?php echo $row['clim']; ?>">
  </div>
  <div class="form-group">
    <label for="j">Disponible</label>
    <input type="text" class="form-control" id="j<?php echo $row['id_v']; ?>" value="<?php echo $row['disponible']; ?>">
  </div>
   <div class="form-group">
    <label for="a">Image</label>
    <input type="text" class="form-control" id="a<?php echo $row['id_v']; ?>" value="<?php echo $row['image']; ?>">
    <img src="../assets/<?php echo $row['image'];?>"width="80px" class="user-image"/>
  </div>
</form>
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
        <button type="button" onclick="updatedata('<?php echo $row['id_v']; ?>')" class="btn btn-primary">sauvegarder</button>
      </div>
    </div>
  </div>
</div>
      
      </td>
    </tr>
<?php
}
?>
  </tbody>
      </table>

</div>
</div>
</div>
</div>
