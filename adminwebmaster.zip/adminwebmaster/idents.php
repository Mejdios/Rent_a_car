<?php

//session_start();
 
 ?>
<?php

session_start();
define('HOST', 'localhost');
define('USER','dietnsgk_location');
define('PASSWORD','hmimide12');
define('BDD','dietnsgk_rentcar');
define('PORT','3306');
 
try
{
    $bdd = new PDO('mysql:host='.HOST.';port='.PORT.';dbname='.BDD, USER, PASSWORD);

    
}
catch(Exception $err)
{
    die('erreur ['.$err->getCode().'] '.$err->getMessage());
}


?>